module.exports = { 
  // database: `mongodb+srv://user:Password@cluster0.wrjz5.mongodb.net/kitravel_db?retryWrites=true&w=majority`,
  database: `mongodb://kitravel2021mongo:unAwMqb0dAlRt24fxF64780393@82.165.48.175:27017/kitravel_db?authSource=admin&readPreference=primary&directConnection=true&ssl=false`,
};